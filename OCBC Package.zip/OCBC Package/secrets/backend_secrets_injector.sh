#!/bin/bash
echo "initiating secrets injector for backend, please see info.sh for reference."
NAMESPACE="backend"
echo "Deleting Existing backend secret"
kubectl delete secret backend-secret -n $NAMESPACE
kubectl create secret generic backend-secret --from-env-file=backend_env.env -n $NAMESPACE
echo "backend secret injected successfully!"




