#!/bin/bash

# Define the prompts
prompts=("Prompt 1" "Prompt 2")
# Define the messages
messages=("Docker Secrets" "Azure Registry Secrets")

#namespace
NAMESPACE1="argo"
NAMESPACE2="backend"
NAMESPACE3="frontend"
# Functions for each specific action

action1() {
    echo "Executing Part 1- Docker Secrets"
    DOCKER_SECRET_NAME="dockercreds"
    kubectl create ns $NAMESPACE2
    kubectl create ns $NAMESPACE3
    echo "Deleting Existing docker-creds secret"
    #delete existing secret
    kubectl delete secret $DOCKER_SECRET_NAME -n $NAMESPACE1
    kubectl delete secret $DOCKER_SECRET_NAME -n $NAMESPACE2
    kubectl delete secret $DOCKER_SECRET_NAME -n $NAMESPACE3
    # Apply the secret using kubectl
    kubectl create secret generic $DOCKER_SECRET_NAME \
        --from-file=.dockerconfigjson=/root/.docker/config.json \
        --type=kubernetes.io/dockerconfigjson \
        -n $NAMESPACE1
    kubectl create secret generic $DOCKER_SECRET_NAME \
        --from-file=.dockerconfigjson=/root/.docker/config.json \
        --type=kubernetes.io/dockerconfigjson \
        -n $NAMESPACE2
    kubectl create secret generic $DOCKER_SECRET_NAME \
        --from-file=.dockerconfigjson=/root/.docker/config.json \
        --type=kubernetes.io/dockerconfigjson \
        -n $NAMESPACE3
    echo "Docker secret injected successfully!"

}

action2() {
    echo "Executing Part 2- Azure Registry Secrets"
    # azure secret injection
    AZURE_TOKEN_SECRET_NAME="acrsecret"
    read -p "Provide azure registry username:" USERNAME
    read -p "Provide azure registry password:" PASSWORD
    read -p "Provide azure registry email:" EMAIL
    #delete existing secret
    echo "Deleting Existing webhook token!"
    kubectl delete secret $AZURE_TOKEN_SECRET_NAME -n $NAMESPACE1
    kubectl delete secret $AZURE_TOKEN_SECRET_NAME -n $NAMESPACE2
    kubectl delete secret $AZURE_TOKEN_SECRET_NAME -n $NAMESPACE3
    kubectl create secret docker-registry acrsecret --docker-server=https://bdbdregistry.azurecr.io --docker-username=$USERNAME --docker-password=$PASSWORD --docker-email=$EMAIL -n $NAMESPACE1
    kubectl create secret docker-registry acrsecret --docker-server=https://bdbdregistry.azurecr.io --docker-username=$USERNAME --docker-password=$PASSWORD --docker-email=$EMAIL -n $NAMESPACE2
    kubectl create secret docker-registry acrsecret --docker-server=https://bdbdregistry.azurecr.io --docker-username=$USERNAME --docker-password=$PASSWORD --docker-email=$EMAIL -n $NAMESPACE3
}

# Array of action functions
actions=(action1 action2)

# Display the prompts
display_prompts() {
    echo "Welcome to Betterdata's secret injector. Please follow the prompts below."
    for i in "${!prompts[@]}"; do
        echo "${prompts[i]} : ${messages[i]}"
    done
}

# Execute a specific part
execute_part() {
    local part=$1
    if [[ $part -ge 1 && $part -le ${#actions[@]} ]]; then
        ${actions[part-1]}
    else
        echo "Invalid option: $part"
    fi
}

# Handle user input
handle_input() {
    local input=$1
    if [ "$input" = "all" ]; then
        # Execute all parts
        for i in $(seq 1 ${#actions[@]}); do
            execute_part $i
        done
    else
        # Split input on commas and execute each part
        IFS=',' read -ra parts <<< "$input"
        for part in "${parts[@]}"; do
            execute_part $part
        done
    fi
}

# Main function
main() {
    display_prompts
    read -p "Enter a number, or numbers separated by commas, or 'all': " user_input
    handle_input "$user_input"
}

# Execute the main function
main
