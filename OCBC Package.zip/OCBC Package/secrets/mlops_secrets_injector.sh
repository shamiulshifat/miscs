#!/bin/bash
echo "initiating secrets injector for mlops server:"
NAMESPACE="argo"
echo "Deleting Existing mlops secret"
kubectl delete secret mlops-secret -n $NAMESPACE
kubectl create secret generic mlops-secret --from-env-file=ml_env.env -n $NAMESPACE
echo "mlops secret injected successfully!"
