#!/bin/bash

#printf "Enter MYSQL root password: "
#read -s MYSQL_ROOT_PASSWORD
#echo

#printf "Enter Mongo root password: "
#read -s MONGO_ROOT_PASSWORD
#echo

#printf "Enter Redis password: "
#read -s REDIS_PASSWORD
#echo
source ./db_creds.env
export MYSQL_ROOT_PASSWORD="$MYSQL_ROOT_PASSWORD"
export MONGO_ROOT_PASSWORD="$MONGO_ROOT_PASSWORD"
export REDIS_PASSWORD="$REDIS_PASSWORD"

# Print the exported environment variables with their values
echo "Exported environment variables:"
echo "MYSQL_ROOT_PASSWORD: $MYSQL_ROOT_PASSWORD"
echo "MONGO_ROOT_PASSWORD: $MONGO_ROOT_PASSWORD"
echo "REDIS_PASSWORD: $REDIS_PASSWORD"