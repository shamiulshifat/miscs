#!/bin/bash

# Function to read images from a file
read_images_from_file() {
  local file_path=$1
  if [[ -f "$file_path" ]]; then
    mapfile -t file_images < "$file_path"
    images+=("${file_images[@]}")
  else
    echo "File not found: $file_path"
    exit 1
  fi
}

# Confirm login to betterdata registry
echo "Confirm you have logged in to the betterdata registry."

# Prompt user to select a text file or all
echo "Select a file to read images from:"
echo "1. argo_images.txt"
echo "2. apps_images.txt"
echo "3. All (argo_images.txt, apps_images.txt)"
read -p "Enter your choice (1, 2, 3): " file_choice

images=()

case $file_choice in
  1)
    read_images_from_file "argo_images.txt"
    ;;
  2)
    read_images_from_file "apps_images.txt"
    ;;
  3)
    read_images_from_file "argo_images.txt"
    read_images_from_file "apps_images.txt"
    ;;
  *)
    echo "Invalid choice. Exiting."
    exit 1
    ;;
esac

# Prompt user to input the registry URL
read -p "Enter the registry URL (e.g., localhost:5000): " local_registry

# Loop through each image
for image in "${images[@]}"; do
  # Pull the image from the original source
  docker pull "$image"

  # Remove the 'bdbdregistry.azurecr.io/' prefix from the image name for tagging
  sanitized_image_name=$(echo "$image" | sed 's|bdbdregistry.azurecr.io/||')

  # Tag the image for the local registry
  docker tag "$image" "$local_registry/$sanitized_image_name"

  # Push the image to the local registry
  docker push "$local_registry/$sanitized_image_name"

  echo "Image $image has been pushed to $local_registry/$sanitized_image_name"
done

echo "All images have been successfully pushed to the registry at $local_registry."
