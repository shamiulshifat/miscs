#!/bin/bash

# List of images to be processed
images=(
  "quay.io/argoproj/argocli:v3.5.4"
  "kong/httpbin:latest"
  "minio/minio:RELEASE.2022-11-17T23-20-09Z"
  "postgres:12-alpine"
  "quay.io/argoproj/workflow-controller:v3.5.4"
  "nats-streaming:0.22.1"
  "natsio/prometheus-nats-exporter:0.8.0"
  "nats:2.10.10"
  "natsio/prometheus-nats-exporter:0.14.0"
  "natsio/nats-server-config-reloader:0.14.0"
  "quay.io/argoproj/argo-events:v1.9.2"
  "whalesay:v3.5.4"
)

# Local registry address
local_registry="localhost:5000"

# Loop through each image
for image in "${images[@]}"; do
  # Pull the image from the original source
  docker pull "$image"
  
  # Tag the image for the local registry, preserving the full original name and tag
  docker tag "$image" "$local_registry/$image"

  # Push the image to the local registry
  docker push "$local_registry/$image"

  echo "Image $image has been pushed to $local_registry/$image"
done

echo "All images have been successfully pushed to the local registry."
