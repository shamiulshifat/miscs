#!/bin/bash
echo "initiating secrets injector for frontend, please see info.sh for reference."
NAMESPACE="frontend"
echo "Deleting Existing frontend secret"
kubectl delete secret frontend-secret -n $NAMESPACE
kubectl create secret generic frontend-secret --from-env-file=frontend_env.env -n $NAMESPACE
echo "frontend secret injected successfully!"
#add azure secret here